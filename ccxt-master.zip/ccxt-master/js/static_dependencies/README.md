// TODO: add web3 and cryptoJS here
