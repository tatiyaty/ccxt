<?php

namespace ccxt;

class ExchangeError extends BaseError {

}
