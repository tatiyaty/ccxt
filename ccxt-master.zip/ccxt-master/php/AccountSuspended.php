<?php

namespace ccxt;

class AccountSuspended extends AuthenticationError {

}