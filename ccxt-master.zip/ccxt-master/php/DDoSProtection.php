<?php

namespace ccxt;

class DDoSProtection extends NetworkError {

}