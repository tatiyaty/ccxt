<?php

namespace ccxt;

use Exception;

class NullResponse extends BadResponse {

}
