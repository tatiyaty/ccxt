<?php

namespace ccxt;

class OrderImmediatelyFillable extends InvalidOrder {

}