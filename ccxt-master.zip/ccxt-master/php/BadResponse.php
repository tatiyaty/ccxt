<?php

namespace ccxt;

use Exception;

class BadResponse extends ExchangeError {

}
