<?php

namespace ccxt;

class PermissionDenied extends AuthenticationError {

}