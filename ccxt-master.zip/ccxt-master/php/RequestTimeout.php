<?php

namespace ccxt;

class RequestTimeout extends NetworkError {

}